 /**************************************************************
 * * Author: Harrison Latimer
 * * Date: 7/29/2017
 * Description: findMedian takes an array of integers, passes
 * the size of the array to selection logic, sorts the array and 
 * finds the median of the set of integers.
 **************************************************************/

#include <algorithm>
#include <iostream>

using namespace std;

//function prototype of findMedian
double findMedian(int userArray[], int sizeArray);

/*
int main() 
{

	int array_1[6] = {12,5,67,88,91,9};

	cout << findMedian(array_1, 6);
	
	return 0;
}
*/

//function declaration of findMedian. returns the median of an array of integers
double findMedian(int userArray[], int sizeArray)
{
	double median; 

	//if the size of the array is an even number take the middle two values, subtract and divide by two 
	if(sizeArray%2==0)
	{

		int midValue_1, midValue_2;

		sort(userArray, userArray + sizeArray);

		midValue_1 = sizeArray/2;
		midValue_2 = midValue_1 - 1; 

		median = ((userArray[midValue_1]+userArray[midValue_2])/double(2));
	}

	//if the size of the array is an odd number take the exact middle value of the set as the median
	else if (sizeArray%2 != 0)
	{
		
		sort(userArray, userArray + sizeArray);
		
		int indexNew = (sizeArray - 1)/double(2);
		
		median = userArray[indexNew];
		
	}

	return median;
}
