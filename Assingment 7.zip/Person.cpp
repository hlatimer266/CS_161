 /**************************************************************
 * * Author: Harrison Latimer
 * * Date: 7/29/2017
 * Description: Implementation file for Person class. Constructor
 * sets class parameters and get methods return the name and 
 * age of instantiated Person objects.
 **************************************************************/
#include "Person.hpp"

//contructor for Person class objects
Person::Person(string name_1, double age_1)
{
	name = name_1;
	age = age_1;
}

//get methods for name and age private class members
string Person::getName()
{
	return name;
}

double Person::getAge()
{
	return age;
}