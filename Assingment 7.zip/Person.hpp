/**************************************************************
 * * Author: Harrison Latimer
 * * Date: 7/29/2017
 * Description: Header file for Person class
 **************************************************************/

//Person.hpp is the Person class specification file
#ifndef PERSON_HPP
#define PERSON_HPP

#include <string>

using namespace std; 

class Person //class declaration
{
	private: 
			string name;
			double age;
	public: 
			//constructor
			Person(string name_1, double age_1); 
			
			//get methods for age and name pricate parameters
			string getName();
	
			double getAge();	
			
};

#endif