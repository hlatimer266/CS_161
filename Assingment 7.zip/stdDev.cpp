 /**************************************************************
 * * Author: Harrison Latimer
 * * Date: 7/29/2017
 * Description: function declaration file for stdDev that returns 
 * the stand deviaton of an array of integer values. 
 **************************************************************/

#include <cmath>
#include "Person.hpp"

double stdDev (Person p_Array[], int size_Array)
{
	double sum = 0; 
	double summation = 0;
	
	 //sum of all values from the array 
	for (int i=0; i<size_Array; ++i)
	{
		sum += p_Array[i].getAge(); 
	}

	//average of all the values of the array
	double average = sum/size_Array;
	
	//the summation of (x-mu)^2 for standard deviaton equation
	for (int k=0; k<size_Array; ++k)
	{
		summation += pow((p_Array[k].getAge()-average),2);
	}
	
	//standard deviation equation
	double std_1 = sqrt(summation/size_Array);
	
	return std_1;
}
