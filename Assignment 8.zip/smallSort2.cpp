/*******************************************************************
 * * Author: Harrison Latimer
 * * Date: 7/31/2017
 * Description: smallSort2 takes three integer values and stores 
 * the address' of these values as pointers and sorts from smallest
 * to largest. Pointee locations will have the values stored in memory
 * but function is void. 
 *******************************************************************/
 
#include <iostream>

using namespace std;

void smallSort(int *num_1, int *num_2, int *num_3);

/*
int main()
{
	int a = 2, b = 10, c = -100;
	smallSort(&a, &b, &c);
	cout << a << " " << b << " " << c;
	return 0;	
}
*/

//declares 3 pointers to values passed from main and using dereferencing 
// passes those values to be sorted to the function logic which alters 
// the values stored in the pointee locations.
void smallSort(int *num_1, int *num_2, int *num_3)
{
	
	if (*num_1 > *num_2)
	{
		int temp = *num_1;
		*num_1 = *num_2;
		*num_2 = temp;
	}
	if (*num_1 > *num_3)
	{
		int temp = *num_1;
		*num_1 = *num_3;
		*num_3 = temp;
	}
	if (*num_2 > *num_3)
	{
		int temp = *num_2;
		*num_2 = *num_3;
		*num_3 = temp;
	}
	 
};

