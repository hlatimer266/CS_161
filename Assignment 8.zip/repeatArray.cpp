/*******************************************************************
 * * Author: Harrison Latimer
 * * Date: 8/4/2017
 * Description: repeatArray takes a dynamically allocated array 
 * and the size of the original array as parameters. The function 
 * creates another dynamically allocated array that is double the 
 * size of the array passed and stores the content of the previous 
 * array twice in sequential order. This is all passed back my reference
 * to the original array passed to the function. 
 *******************************************************************/
#include <iostream>
using namespace std ;

void repeatArray ( double *&Old , int old_size) ;
/*
int main ( ) {

    double* array1 = new double [3] ;
    
    for (int i=0;i<3;i++)
		array1[i] = (i+i)*2;

	repeatArray ( array1 , 3 ) ;
	
	
	for (int j=0;j<6;j++)
		cout << array1[j] << endl;

	delete[] array1;
	array1 = NULL;
	
}
*/

void repeatArray ( double *&Old , int old_size) {
	
     //create dynamic array to allocate memoary on the heap
     double * temp = new double [ old_size ] ;

	//copy the array passed as a parameter to the dynamically allocated array temp
     for ( int i = 0 ; i < old_size ; i ++ ) {

        temp [ i ] = Old [ i ] ;

     }
     
     //release the memory of the passed array
     delete []Old;
     Old = NULL;
     
     //reinitialize the passed array and double the size
     Old = new double [ old_size *2 ] ;

	//copy the original contents of the passed array to the first half of the array
     for ( int k = 0 ; k < old_size ; k ++ ) {

        Old [ k ] = temp [ k ] ;
    }
     
	 //copy the contents of the passed array to the second half of the array   
    for ( int j = (old_size*2 )/2; j < old_size*2 ; j ++ ) {

        Old [ j ] = temp [ j-old_size ] ;
        
     }

	//release temp from memory
     delete [] temp ;
     temp = NULL;

}


