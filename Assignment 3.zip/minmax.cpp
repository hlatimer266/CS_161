/**************************************************************
 * * Author: Harrison Latimer
 * * Date: 7/6/2017
 * Description: Program takes user specified number of integers,
 * asks for that number of integers, and finds the max / min of 
 * the set.
 **************************************************************/

#include <iostream>
using namespace std;

int main()
{
	int num_Ints, user_Int, min_Num = 0, max_Num = 0 ;
	
	//Get total number of integers
	cout << "How many intergers would you like to enter?"<< endl;
	cin >> num_Ints;
	
	cout << "Please Enter " << num_Ints << " integers.\n";
	
	//min_Num and max_Num initialized at 0 and each intger is compared
	// and saved if its bigger or smaller then the previous integer. 
	for (int i = 0; i < num_Ints; i++)
	{
		cin >> user_Int;
		
		if (user_Int > max_Num)
		{
			max_Num = user_Int;
		 } 
		else if (user_Int < min_Num)
		{
			min_Num = user_Int;
		}
		
	 } 
	
	// Max and Min output of integer set
	cout << "min: " << min_Num << endl; 
	cout << "max: " << max_Num << endl;
	
    return 0;
}
