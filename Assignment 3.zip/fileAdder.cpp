/****************************************************************
 * * Author: Harrison Latimer
 * * Date: 7/9/2017
 * Description: User inputs file path, program checks if input is 
 * valid. If valid, sum of the values in file are added and written
 * to a seperate file. If invalid program prints error message to 
 * screen
 ****************************************************************/
 
#include <iostream>
#include <fstream>
#include <string>
using namespace std;

int main()
{
	
 string user_InputFile;
 int sum, numFromFile;
 
 //Saves user input as a string for inputFile.open() function
 cout << "Please insert file path"<<endl;
 cin >> user_InputFile;
 
  // Combine object creation for input and output files in one step
  ifstream inputFile;
  ofstream outputFile;
  
  //Test inputFile to see if it exists / is openable 
  if (inputFile)
    {
  	inputFile.open(user_InputFile);
  	
    while (inputFile >> numFromFile)
     {
  	  sum += numFromFile;
     }
    }
    
  else 
  	{  
 	cout << "could not access file" << endl;
    }
    
  inputFile.close();
  
  //Creates sum.txt file to print sum of input file.
  outputFile.open("sum.txt");
  
  outputFile << sum << endl;
  
  outputFile.close();
  
  return 0;
}
