/**************************************************************
 * * Author: Harrison Latimer
 * * Date: 7/7/2017
 * Description: User enters integer number for different user 
 * to guess the value of. Program tells user if guess is too 
 * high or too low.
 **************************************************************/

#include <iostream>
using namespace std;

int main()
{
	// Variable num_Guess initialized at 1 otherwise guess count is off
	// by one.
	int user_Int, guess_Int, num_Guess = 1 ;
	
	cout << "Enter the number for the player to guess."<< endl;
	cin >> user_Int;
	
	cout << "Enter your guess." << endl;
	cin >> guess_Int;
	
	// Loop runs as long as integer guessed is not equal to user entered
	// integer. Excecutes if statement to tell user if too high or too low.
	while (guess_Int != user_Int)
	{
		num_Guess++;
		
		if (guess_Int > user_Int) 
		{
			cout << "Too high - try again." << endl;
			cin >> guess_Int;
		}
		else if (guess_Int < user_Int)
		{
			cout << "Too low - try again." << endl;
			cin >> guess_Int;
		}
	}
	
	// num_Guess is iterating over each loop and will tell 
	// the user their number of guesses.
	cout << "You guessed it in " << num_Guess << " tries.\n";
	
    return 0;
}
