/*******************************************************************
 * * Author: Harrison Latimer
 * * Date: 7/11/2017
 * Description: smallSort takes three integer values adn sorts them  
 * from smallest to largest. These numbers are passed back to the 
 * calling function by reference and its memory locations have 
 * the sorted values stored at the original memory locations.
 *******************************************************************/
 
#include <iostream>

using namespace std;

/*
int main()
{
	int a = 14, b = -90, c = 2;
	smallSort(a, b, c);
	cout << a << " " << b << " " << c;
	return 0;	
}
*/

void smallSort(int &num_1, int &num_2, int &num_3)
{
	
	if (num_1 > num_2)
	{
		int temp = num_1;
		num_1 = num_2;
		num_2 = temp;
	}
	else if (num_1 > num_3)
	{
		int temp = num_1;
		num_1 = num_3;
		num_3 = temp;
	}
	else if (num_2 > num_3)
	{
		int temp = num_2;
		num_2 = num_3;
		num_3 = temp;
	}
	 
}

