/****************************************************************
 * * Author: Harrison Latimer
 * * Date: 7/11/2017
 * Description: User enters time in seconds an object is falling 
 * and function returns the distance the object has fallen in 
 * that time period.
 ****************************************************************/
 
#include <iostream>
#include <cmath>

using namespace std;

/*
int main()
{
	double fall_time;
	
	cout << "Please enter fall time (in seconds) " << endl;
	cin >> fall_time;
	
	cout << fallDistance(fall_time);

	return 0;	
}
*/

double fallDistance(double time_1)
{
	double gravity = 9.8, distance;
	
	return distance = 0.5*gravity*pow(time_1,2);
	 
}

