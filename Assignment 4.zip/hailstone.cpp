/****************************************************************
 * * Author: Harrison Latimer
 * * Date: 7/11/2017
 * Description: Pass integer value into hailstone fucntion and 
 * it iterates through arithmetic operations until integer value 
 * equals one. Returns number of steps to reduce user entered 
 * integer to one.
 ****************************************************************/
 
#include <iostream>
using namespace std;

/*
int main()
{
	int user_Int;
	
	cout <<"Enter an integer > 1" << endl;
	cin >> user_Int;
	
	cout << hailstone(user_Int);

	return 0;	
}
*/

int hailstone(int enter_Int)
{
	int steps; 
	
	if (enter_Int == 1)
	{
		steps = 0;	
	}
	
	else 
	{
		while (enter_Int != 1)
		{
			steps ++;
			if (enter_Int % 2 == 0)
			{
				enter_Int = enter_Int / 2;
			}
			
			else if (enter_Int % 2 != 0)
			{
		    	enter_Int = (3*enter_Int) + 1;
			}
		}
		
	}
	
	return steps;
	 
}
