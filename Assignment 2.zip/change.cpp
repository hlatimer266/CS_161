/*************************************************************
 * * Author: Harrison Latimer
 * * Date: 6/30/2017
 * Description: User enters integer change value and gets 
 * smallest number of coins needed to make it
 *************************************************************/

#include <iostream>
using namespace std;

// Use integer division to find number of each denomination and modulo num_cents before 
//every iteration for smallest combination of coins needed. 
int main()
{
	int num_cents, cents_q, cents_d, cents_n, cents_p;
	
	cout << "Please enter an amount in cents less than a dollar\n";
	cin >> num_cents;
	
	cents_q = (num_cents/25);
	num_cents = num_cents%25;
	
	cents_d = (num_cents/10);
	num_cents = num_cents%10;
	
	cents_n = (num_cents/5);
	num_cents = num_cents%5;
	
	cents_p = (num_cents/1);
	
	cout << "Your change will be:" << endl;
	cout << "Q: " << cents_q <<endl;
	cout << "D: " << cents_d <<endl;
	cout << "N: " << cents_n <<endl;
	cout << "P: " << cents_p <<endl;
	
    return 0;
}
