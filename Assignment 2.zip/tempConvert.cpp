/*************************************************************
 * * Author: Harrison Latimer
 * * Date: 6/29/2017
 * Description: User inputs Celsius temperature and program 
 * returns Fahrenheit
 *************************************************************/

#include <iostream>
using namespace std;

// takes Celsius temperture and converts to Fahreneit
int main()
{
	double temp_C, temp_F;
	
	cout << "Please enter Celsius tempeture" << endl;
	cin >> temp_C; 
	
	temp_F = (static_cast<double>(9)/5)*temp_C + 32;
	
	cout << "The equivalent Fahrenheit temperature is:\n";
	cout << temp_F << endl;
	
    return 0;
}
