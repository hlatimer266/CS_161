/*************************************************************
 * * Author: Harrison Latimer
 * * Date: 6/29/2017
 * Description: User inputs 5 numbers and returns average of 
 * those 5 numbers
 *************************************************************/

#include <iostream>
using namespace std;

// this program takes 5 float variables and prints the average
int main()
{
	double num1, num2, num3, num4, num5, average;
	
	cout << "Please enter five numbers" << endl;
	cin >> num1 >> num2 >> num3 >> num4 >> num5; 

	average = (num1 + num2 + num3 + num4 + num5) / 5;
	
	cout << "The average of those numbers is:\n";
	cout << average << endl;
	
    return 0;
}
