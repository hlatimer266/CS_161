/**************************************************************
 * * Author: Harrison Latimer
 * * Date: 8/16/2017
 * Description: implementation file for Customer Class
 **************************************************************/ 

#include <string>
#include <vector>
#include <iostream>
#include "Customer.hpp"

using namespace std; 

//class constructor
Customer::Customer(string n, string a, bool pm){
	name = n;
	accountID = a;
	premiumMember = pm;	
}

//get methods for Customer class
string Customer::getAccountID(){
	return accountID;
}

vector<string> Customer::getCart(){
	return cart;
}

//add members to cart vector 
void Customer::addProductToCart(string c){
	cart.push_back(c);
	
}

//check to see if Customer is a premium member
bool Customer::isPremiumMember(){
	if (premiumMember == true ){
		return true;
	}
	else 
		return false;
}
	
//clear cart vector
void Customer::emptyCart(){
	cart.clear();	
}