/**************************************************************
 * * Author: Harrison Latimer
 * * Date: 8/16/2017
 * Description: implementation file for Product Class
 **************************************************************/ 
#include <iostream>
#include <string>
#include <vector>
#include "Product.hpp"

//class constructor 
 Product::Product(string id, string t, string d, double p, int qa)
 {
 	idCode = id;
    title = t;
    description = d;
    price = p;
    quantityAvailable = qa;
 }
 
//get methods for all class parameters
string Product::getIdCode()
{
	return idCode;
}
string Product::getTitle()
{
	return title;
}
string Product::getDescription()
{
	return description;
}
double Product::getPrice()
{
	return price;
}
int Product::getQuantityAvailable()
{
	return quantityAvailable;
}

//method to decrease class parameter by 1
void Product::decreaseQuantity(){
	quantityAvailable -= 1;
}