/**************************************************************
 * * Author: Harrison Latimer
 * * Date: 8/16/2017
 * Description: implementation file for Store Class
 **************************************************************/ 

#include <iostream>
#include <algorithm>
#include "Customer.hpp"
#include "Product.hpp"
#include "Store.hpp"
using namespace std;

//set methods for Store class private parameters
void Store::addProduct(Product* p){
	inventory.push_back(p);
	
}
void Store::addMember(Customer* c){
	members.push_back(c);
	
}

//verifies that a particular product ID for an instantation of the class exists
Product* Store::getProductFromID(string prdId){
	
	for (int i = 0; i < inventory.size(); ++i){
		if (inventory.at(i)->getIdCode() == prdId)
			return inventory.at(i);
		}
	return NULL;
				
}

//verifies that a particular member ID for an instantation of the class exists
Customer* Store::getMemberFromID(string mems){
	
	for (int k = 0; k < members.size(); k++){
		if (members.at(k)->getAccountID() == mems)
			return members.at(k);
		}
	return NULL;
	
}

//searches the inventory of the class based on the passed argument and returns if there are any 
// matches in either the titles or descriptions of products
void Store::productSearch(string str){
	
	transform(str.begin(), str.end(), str.begin(), ::tolower);
		
	for (int k = 0; k < inventory.size(); k++)
	{
		
		string titleCheck = inventory[k]->getTitle();
		transform(titleCheck.begin(), titleCheck.end(),titleCheck.begin(), ::tolower);
		
		string descripCheck = inventory[k]->getDescription();
		transform(descripCheck.begin(), descripCheck.end(),descripCheck.begin(), ::tolower);
		
		
		if ((descripCheck.find(str) != string::npos) || (titleCheck.find(str) != string::npos)){
			cout << inventory.at(k)->getTitle() <<endl;
			cout << inventory.at(k) -> getIdCode() << endl;
			cout << inventory.at(k) -> getDescription() << endl;
			cout << inventory.at(k) -> getPrice() << endl;
			}
				
		
	}
}

//adds a Product to a particular memebers cart. checks if the member / product are found 
// as well as if the item is in stock. 	
void Store::addProductToMemberCart(string pID, string mID){
	
	int k = 0;
	Product *p = getProductFromID(pID);
	Customer *c = getMemberFromID(mID);
	string productID;
	
	if ( p == NULL){
		cout << "Product"<< pID << " not found" << endl;
	}
	else if (c == NULL){
		cout << "Member" << mID << "not found";
	}
	
	else if (p->getQuantityAvailable() > 0)
	{
		productID = p->getIdCode();
		c->addProductToCart(productID);
	}
	else
		cout << "Sorry" << p << " is out of stock" << endl;	
	
}
			

//takes a memebers ID and prints the total cost of items in the cart
void Store::checkOutMember(string mID)
{
	Customer *c = getMemberFromID(mID);
	Product *p; 
	string ProductID = "";
	double subTotal = 0.0;
	double totalShippingCost;
	
	int cartSize = c->getCart().size();
	
	if (c == NULL)
		cout << "Member " << mID << " not found"<< endl;
	else 
	{
		
		for (int i = 0; i < cartSize; i++)
		{
			ProductID = c->getCart().at(i);
			p = getProductFromID(ProductID);
			if (p->getQuantityAvailable() <= 0)
				cout << "Sorry " << ProductID << " is not available" << endl; 
			else 
			{	
				cout << p->getTitle() << " - " << "$" << p->getPrice() << endl;
				subTotal += p->getPrice();
				p->decreaseQuantity();
			}
		}
	}
	
	cout << "subtotal = " << subTotal << endl;
	if (c->isPremiumMember()==false)
		totalShippingCost = subTotal*0.07;
	else 
		totalShippingCost = 0.0;
	cout << "shipping = " << "$"<< totalShippingCost << endl;
	
	cout << "total = " << "$"<< subTotal + totalShippingCost << endl;
	
	c->emptyCart();
	
		
	}