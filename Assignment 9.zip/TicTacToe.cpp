/**************************************************************
 * * Author: Harrison Latimer
 * * Date: 8/11/2017
 * Description: Implementation file for TicTactoe class
 **************************************************************/

#include "TicTacToe.hpp"
#include <iostream>

// Default Constructor
TicTacToe::TicTacToe()
{
    playerturn = true;
}

//Constructor
TicTacToe::TicTacToe(char c)
{
    if (c == 'x')
        playerturn = true;
    else
        playerturn = false;
}

//method that loops until a win, draw, or unfinished 
void TicTacToe::play()
{
    // print an empty board to screen
    gameTable.print();
    
    int x_coord = 0; 
    int y_coord = 0; 
    
    // loop until there is a winner / loser
    while (gameTable.gameState() == UNFINISHED)
    {
        // Prompt user X for move
        if (playerturn)
        {
            cout << "Player X: please enter your move. " << endl;
            cin >> x_coord;
            cin >> y_coord;
            
            if (!gameTable.makeMove(x_coord, y_coord, 'x'))
                cout << "That square is already taken." << "\n";
            else
                playerturn = false;  // if valid, Player O's turn
        }
        
        // Prompt user o for move
        else
        {
            cout << "Player O: please enter your move. " << endl;
            cin >> x_coord;
            cin >> y_coord;
            
            if (!gameTable.makeMove(x_coord, y_coord, 'o'))
                cout << "That square is already taken." << "\n";
            else
                playerturn = true;  
        }
    
        gameTable.print();
    }
    
    // print result to screen when there is a winner / draw
    if (gameTable.gameState() == X_WON)
        cout << "Congratulations! Player X wins!" << "\n";
    else if (gameTable.gameState() == O_WON)
        cout << "Congratulations! Player O wins!" << "\n";
    else if (gameTable.gameState() == DRAW)
        cout << "It's a draw." << "\n";
}


//main method

int main()
{
    
    char player; 

    cout << "Which player will go first? (x / o)" << "\n";
    cin >> player;
    
    
    TicTacToe game(player);
    
    
    game.play();
    
    return 0;
}
