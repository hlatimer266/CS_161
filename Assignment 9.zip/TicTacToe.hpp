/**************************************************************
 * * Author: Harrison Latimer
 * * Date: 8/11/2017
 * Description: Header file for TicTacToe class
 **************************************************************/

#ifndef TICTACTOE_HPP
#define TICTACTOE_HPP 

#include "Board.hpp"
 
#include <iostream>

using namespace std;

//class declaration
class TicTacToe {
	private:
		// instantiate Board class
		Board gameTable; 
		
		//stores which player, either 'x' or 'o' goes first
		bool playerturn;

	public:
		
		//default constructor
		TicTacToe();
		
		//constructor
		TicTacToe(char player);
		
		//method to keep the game going until one player wins, draws, or game goes unfinished
		void play(); 

};
#endif
