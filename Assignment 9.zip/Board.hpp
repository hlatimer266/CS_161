/**************************************************************
 * * Author: Harrison Latimer
 * * Date: 8/10/2017
 * Description: Header file for Board class
 **************************************************************/
#ifndef BOARD_HPP
#define BOARD_HPP 
 
#include <iostream>

using namespace std; 

enum State{X_WON, O_WON, DRAW, UNFINISHED};

//class declaration
class Board {
	private: 
		char gameBoard[3][3];
	public: 
		//default constructor
		Board();
		
		 //set method for Board class
		bool makeMove(int x, int y, char player);
			
		//returns result (W/L/D) or game
		State gameState();
		
		//prints the game board to the screen
		void print();
						
};

#endif
