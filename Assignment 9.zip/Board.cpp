/**************************************************************
 * * Author: Harrison Latimer
 * * Date: 8/10/2017
 * Description: Header file for Board class
 **************************************************************/

#include "Board.hpp"
#include <iostream>

//default contructor for Board Class
Board::Board()
	{
			for(int i = 0; i < 3 ; i++){
				for (int k = 0; k < 3; k++){
					gameBoard[i][k] = ' ';}
				}
		}
		
//set method for Board class. returns T/F depending on contents of gameBaord array
bool Board::makeMove(int x, int y, char player)
			{
					if (gameBoard[x][y] == ' ')
				{
					gameBoard[x][y] = player;
					return true;
				}
				else 
					return false;
			}

//returns winner of the game			
State Board::gameState()
{

    State playerX = UNFINISHED;
    State playerO = UNFINISHED;

    //tests vertical coordinates for a winner
    for(int i = 0; i < 3;i++){
        if(gameBoard[0][i] == 'x' && gameBoard[1][i] == 'x' && gameBoard[2][i] == 'x'){
            playerX = X_WON;
        }
        else  if(gameBoard[0][i] == 'o' && gameBoard[1][i] == 'o' && gameBoard[2][i] == 'o'){
            playerO = O_WON;
        }
    }
    //tests horizontal coordinates for a winner
    for(int i = 0; i < 3;i++){
        if(gameBoard[i][0] == 'x' && gameBoard[i][1] == 'x' && gameBoard[i][2] == 'x'){
            playerX = X_WON;
        }
        else  if(gameBoard[i][0] == 'o' && gameBoard[i][1] == 'o' && gameBoard[i][2] == 'o'){
            playerO = O_WON;
        }
    }
    //tests diagonal coordinates for a winner
    if(gameBoard[0][0] == 'x' && gameBoard[1][1] == 'x' && gameBoard[2][2] =='x'){
        playerX = X_WON;
    }
    else if(gameBoard[0][0] == 'o' && gameBoard[1][1] == 'o' && gameBoard[2][2] =='o'){
        playerO = O_WON;
    }

    if(gameBoard[2][0] == 'x' && gameBoard[1][1] == 'x' && gameBoard[0][2] =='x'){
        playerX = X_WON;
    }
    else if(gameBoard[2][0] == 'o' && gameBoard[1][1] == 'o' && gameBoard[0][2] =='o'){
        playerO = O_WON;
    }

    //tests to see if there is a draw
    int freespaces = 0;
    for(int i = 0;i < 3;i++){
        for(int j =0;j < 3;j++){
            if(gameBoard[i][j] != ' '){
                freespaces++;
            }
        }
    }

    //returns which player won
    if(playerX == X_WON && playerO == UNFINISHED){
        
        return X_WON;
    }
    else if(playerX == UNFINISHED && playerO == O_WON){
        
        return O_WON;
    }
    else if(freespaces == 9){
        
        return DRAW;
    }
    else if(playerX == UNFINISHED && playerO == UNFINISHED){
        
        return UNFINISHED;
    }

}

//prints gameBaord array to screen		
void Board::print()
{
 // Set horizontal axis
    cout << "\n" << "   0  1  2  \n";
    
    for (int i=0; i < 3; i++)
    {
        // Output row number
        cout << i << "  ";
        
        // Output the game board
        for (int j=0; j < 3; j++)
            cout << gameBoard[i][j] << "  ";
        
        cout << endl;
    }
    
    cout << endl;
    return;
}
