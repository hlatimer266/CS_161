 /**************************************************************
 * * Author: Harrison Latimer
 * * Date: 7/19/2017
 * Description: Implementation file using Taxicab header file. 
 * Functions below initiate, get and change member variables of 
 * Taxicab class. 
 **************************************************************/

// Taxicab.cpp is the Taxicab class function implementation file.
 #include "Taxicab.h"
 #include <cmath>
 using namespace std;
 /*******************************************************************
 * Taxicab::Taxicab *
 * Contructor to set member variables x_Coordinate, y_Coordinate 
 * and total_Distance
 *******************************************************************/
 Taxicab::Taxicab(int x_Coor,int y_Coor)
 {
 	x_Coordinate = x_Coor;
 	y_Coordinate = y_Coor;
 	total_Distance = 0; 
 }

 /**************************************************************
 * Taxicab::getXCoord() *
 * get method to set member variable x_Coordinate. *
 **************************************************************/
 int Taxicab::getXCoord()
 {
 return x_Coordinate;
 }

 /*******************************************************************
 * * Taxicab::getYCoord() *
 * get method to set member variable y_Coordinate. *
 *******************************************************************/
 int Taxicab::getYCoord()
 {
 return y_Coordinate;
 }

 /*******************************************************************
 * * * Taxicab::getDistanceTraveled() *
 * get method to set member variable total_Distance. *
 *******************************************************************/
 int Taxicab::getDistanceTraveled()
 {
 	
 	return total_Distance;
 }

 /*******************************************************************
 * Taxicab::moveX *
 * This function takes the value storeed and x_Coordinate and adds 
 * to user input for a move in the X coordinate plane. 
 *******************************************************************/
 void Taxicab::moveX(int move_x)
 {
 	
 	x_Coordinate += move_x;
 	total_Distance += abs(move_x);

 	return;
 }

  /*******************************************************************
 * Taxicab::moveY *
 * This function takes the value storeed and y_Coordinate and adds 
 * to user input for a move in the Y coordinate plane. 
 *******************************************************************/
 void Taxicab::moveY(int move_y)
 {
 	
 	y_Coordinate += move_y;
 	total_Distance += abs(move_y);

 	return;
 }