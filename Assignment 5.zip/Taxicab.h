 /**************************************************************
 * * Author: Harrison Latimer
 * * Date: 7/19/2017
 * Description: Header file for Taxicab class
 **************************************************************/

 // Taxicab.h is the Taxicab class specification file.
 #ifndef TAXICAB_H
 #define TAXICAB_H

 // Taxicab class declaration
 class Taxicab
 {
 private:
 	int x_Coordinate; 
 	int y_Coordinate;
 	int total_Distance;
 	
 public:
 	Taxicab ()
 	{
 		x_Coordinate = 0; 
 		y_Coordinate = 0;
 		total_Distance = 0;
 	}
 	Taxicab(int x_Coor,int y_Coor);
 	int getXCoord();
 	int getYCoord();
 	int getDistanceTraveled();
 	void moveX(int move_x);
 	void moveY(int move_y);
 };
 #endif