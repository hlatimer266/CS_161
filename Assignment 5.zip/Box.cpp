/**************************************************************
 * * Author: Harrison Latimer
 * * Date: 7/19/2017
 * Description: Implementation file using Box header file. 
 * functions below initiate and sets parameters of Box
 * class. Also returns volume and surface area of a Box 
 * object. 
 **************************************************************/
// Box.cpp is the Box class function implementation file.
 #include "Box.h"

 /*******************************************************************
 * Box::Box *
 * Constructor method to initialze member variables height, length, and 
 * width in Box class.
 *******************************************************************/
 Box::Box(double h, double len, double w)
 {
 	height = h;
 	length = len; 
 	width = w;
 }

 /*******************************************************************
 * Box::setLength *
 * set method for length member variable in Box class. *
 *******************************************************************/
 
 void Box::setLength(double len)
 {
 
 length = len; // copy it to length
 
 return;
 }

 /******************************************************************
 * Box::setWidth *
 * set method for width member variable in Box class. *
 ******************************************************************/
 
 void Box::setWidth(double w)
 {
 
 width = w; // copy it to width
 
 return;
 }

/******************************************************************
 * Box::setHeight *
 * set method for height memeber variable in Box class. *
 ******************************************************************/
 
 void Box::setHeight(double h)
 {
 
 height = h; // copy it to width
 
 return;
 }

 /**************************************************************
 * Box::calcVolume *
 * This function returns the volume of a box using Box class 
 * member variables.
 **************************************************************/
 double Box::calcVolume()
 {
 return length*width*height;
 }

 /*******************************************************************
 * Box::CalcSurfaceArea *
 * This function calculates and returns the surface area of the 
 * box using Box class member variables.
 *******************************************************************/
 double Box::calcSurfaceArea()
 {
 return (2*length*width)+(2*length*height)+(2*width*height);
 }
