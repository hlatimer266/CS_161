 /**************************************************************
 * * Author: Harrison Latimer
 * * Date: 7/19/2017
 * Description: Header file for Box class
 **************************************************************/

 // Box.h is the Box class specification file.
 #ifndef BOX_H
 #define BOX_H

 // Box class declaration
 class Box
 {
 private:
 	double height;
 	double length;
 	double width;
 
 public:
 	Box ()
 	{
 		height = 1;
 	    length = 1;
 	    width = 1;
 	}
 	Box(double h, double len, double w);
 	
 	double calcVolume();
 	double calcSurfaceArea();
 };
 #endif
