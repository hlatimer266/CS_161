 /**************************************************************
 * * Author: Harrison Latimer
 * * Date: 7/25/2017
 * Description: Implementation file using EntreeSampler.hpp and 
 * Entree.hpp header files. Class methods return the names of 
 * Entrees and total calories from the Entree class.
 **************************************************************/
//Header files from EntreeSampler and Entree classes
#include "EntreeSampler.hpp"
#include "Entree.hpp"

#include <string>
#include <iostream>

using namespace std;

 /*******************************************************************
 * EntreeSampler::EntreeSampler *
 * Constructor for EntreeSampler class using Entree class parameter 
 * type.
 *******************************************************************/
EntreeSampler::EntreeSampler(Entree ent_1, Entree ent_2, Entree ent_3, Entree ent_4)
{
	en_1 = ent_1;
	en_2 = ent_2;
	en_3 = ent_3;
	en_4 = ent_4;

}

/*******************************************************************
 * EntreeSampler::listEntrees *
 * void function that prints names of Entree class parameters.
 *******************************************************************/ 
void EntreeSampler::listEntrees()
{
	cout << en_1.getName() + " " + en_2.getName() + " " + en_3.getName() + " " + en_4.getName() << endl;
	return; 
}

/*******************************************************************
 * EntreeSampler::totalCalories *
 * int function that returns sum of all Entree's entered calories.
 *******************************************************************/ 
int EntreeSampler::totalCalories()
{
	return en_1.getNumCalories()+en_2.getNumCalories()+en_3.getNumCalories()+en_4.getNumCalories();
}