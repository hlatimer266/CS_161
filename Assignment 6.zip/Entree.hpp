 /**************************************************************
 * * Author: Harrison Latimer
 * * Date: 7/25/2017
 * Description: Header file for Entree class
 **************************************************************/

//Entree.hpp is the Entree class specification file
#ifndef ENTREE_HPP
#define ENTREE_HPP 
#include <string>

using namespace std;

class Entree 
{
private:
	string name_Entree;
	int num_Calories; 

public:
	//Default constructor for Entree class 
	Entree(){
		name_Entree = "";
		num_Calories = 0;
	}
	//Constructor for Entree class
	Entree(string e_1, int cal_1);

	string getName();

	int getNumCalories();
};
#endif
