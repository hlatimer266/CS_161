 /**************************************************************
 * * Author: Harrison Latimer
 * * Date: 7/25/2017
 * Description: Implementation file for Entree class using 
 * Entree.hpp header file. Class methods return the name 
 * and calories for each instantiation of Entree class.
 **************************************************************/
#include "Entree.hpp"
#include <string>

using namespace std;

/*******************************************************************
 * Entree::Entree *
 * Constructor for Entree class parameters 
 *******************************************************************/
Entree::Entree(string e_1, int cal_1)
{
	name_Entree = e_1;
	num_Calories = cal_1;

}

/*******************************************************************
 * Entree::getName *
 * Get method for name_Entree class parameter. Returns string.
 *******************************************************************/
string Entree::getName()
{
	return name_Entree;
}

/*******************************************************************
 * Entree::getName *
 * Get method for num_Calories class parameter. Returns an integer.
 *******************************************************************/
int Entree::getNumCalories()
{
	return num_Calories;
}


