/**************************************************************
 * * Author: Harrison Latimer
 * * Date: 7/25/2017
 * Description: Header file for Quadratic class
 **************************************************************/

//Quadratic.hpp is the Quadratic class specification file
#ifndef QUADRATIC_HPP
#define QUADRATIC_HPP

class Quadratic // class declaration
{
private:
	double a;
	double b;
	double c; 

public: 
	//default constructor
	Quadratic()
	{
		a = 1.0;
		b = 1.0;
		c = 1.0;
	}
	//Constructor
	Quadratic(double a_1, double b_1, double c_1);

	//Returns x value of quadratic equation
	double valueFor(double x_1);

	//returns number of real roots of quadratic equation
	int numRealRoots();

	//get methods for A,B,C, and X
	double getA(); 
	double getB();
	double getC();


	//set methods for A,B,C, and X
	void setA(double a_1); 
	void setB(double b_1);
	void setC(double c_1);
	
};
#endif