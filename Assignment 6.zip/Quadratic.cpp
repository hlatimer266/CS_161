 /**************************************************************
 * * Author: Harrison Latimer
 * * Date: 7/25/2017
 * Description: Implementation file for Quadratic class using 
 * Quadratic.hpp header file. Class methods get and set class 
 * parameters a,b, and c. Other calss method return the 
 * value of a quadratic function and the number of real roots 
 * based on the Qudaratic class variables.
 **************************************************************/
#include <iostream>
#include <cmath>

//
#include "Quadratic.hpp"

using namespace std;


 /*******************************************************************
 * Quadratic::Quadractic *
 * Constructor method to set Quadratic class parameters for a, b, and c
 * on object instantiation.  
 *******************************************************************/
Quadratic::Quadratic(double a_1, double b_1, double c_1)
{
	a = a_1;
	b = b_1;
	c = c_1;
}

 /*******************************************************************
 * Quadratic::setA *
 * set method for "a" parameter in Quadratic class. *
 *******************************************************************/
 void Quadratic::setA(double a_1) 
 {
 	a = a_1;	
 }

 /*******************************************************************
 * Quadratic::setB *
 * set method for "b" parameter in Quadratic class. *
 *******************************************************************/
 void Quadratic::setB(double b_1)
 {
 	b = b_1;	
 }

/*******************************************************************
 * Quadratic::setC *
 * set method for "c" parameter in Quadratic class. *
 *******************************************************************/
 void Quadratic::setC(double c_1)
 {
 	c = c_1;
 }

/*******************************************************************
 * Quadratic::getA *
 * get method for "a" parameter in Quadratic class. *
 *******************************************************************/
double Quadratic::getA() 
{
	return a;
}

/*******************************************************************
 * Quadratic::getB *
 * get method for "b" parameter in Quadratic class. *
 *******************************************************************/
double Quadratic::getB()
{
	return b;
}

/*******************************************************************
 * Quadratic::getC *
 * get method for "c" parameter in Quadratic class. *
 *******************************************************************/
double Quadratic::getC()
{
	return c;
}

/*******************************************************************
 * Quadratic::valueFor *
 * returns value of f(x) based on a standard quadratic function 
 * a^2X + bX + c . *
 *******************************************************************/
double Quadratic::valueFor(double x_1)
{
 
	cout << "a = " <<  a << endl;
	return (pow(a,2)*x_1)+(b*x_1)+c ;
}

/*********************************************************************
 * Quadratic::numRealRoots *
 * using the discrement of a quadratic function (b^2-4ac), numRealRoots
 * returns either 0,1, or 2 based on the evaulation of the discrement.
 *********************************************************************/
int Quadratic::numRealRoots()
{

	double discrement; 
	int real_Roots;

	discrement = pow(b,2) - (4*a*c);

	if (discrement >= 0 && discrement <= 0.00001)
	{
		real_Roots = 1;
	}
	else if (discrement > 0.00001)
	{
		real_Roots = 2;
	}
	else if (discrement < 0)
	{
		real_Roots = 0;
	}

	return real_Roots;
}
