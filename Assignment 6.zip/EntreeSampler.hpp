 /**************************************************************
 * * Author: Harrison Latimer
 * * Date: 7/25/2017
 * Description: Header file for EntreeSampler class
 **************************************************************/

//EntreeSampler.hpp is the EntreeSampler class specification file
#ifndef ENTREESAMPLER_HPP
#define ENTREESAMPLER_HPP 

#include <string>

//link to Entree.hpp class specification file to use Entree class
#include "Entree.hpp"

using namespace std;

class EntreeSampler 
{
private:
	Entree en_1;
	Entree en_2;
	Entree en_3;
	Entree en_4;
public:
	
	//Constructor for EntreeSampler class
	EntreeSampler(Entree ent_1, Entree ent_2, Entree ent_3, Entree ent_4);

	void listEntrees();

	int totalCalories();

};
#endif
